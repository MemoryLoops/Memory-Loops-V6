
function generateMemory() {
    const input = document.getElementById("memoryInput").value;
    const prompt = document.getElementById("promptSelect").selectedOptions[0].text;
    const output = document.getElementById("output");

    const memoryText = `Dear Family,

${prompt}...

${input}

With love,
Memory Loops`;
    output.textContent = memoryText;
}

function exportPDF() {
    const element = document.getElementById("output");
    html2pdf().from(element).save("memory.pdf");
}
